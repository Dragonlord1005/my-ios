public class Calculator {

    public init() {}

    public func multitply(_ valueX: Int, with valueY: Int) -> Int {
        return valueX * valueY
    }
}
