import XCTest

import CalculatorTests

var tests = [XCTestCaseEntry]()
tests += CalculatorTests.allTests()
XCTMain(tests)
