# Calculator-github-actions

This repo is just the final version on how to test and deploy an iOS project using exclusively Github Actions.

Medium [story](https://medium.com/@tiagosanto/test-and-deploy-an-ios-app-using-github-actions-44de9a7dcef6) about this repo.
